module.exports = {
  bets: require('./bets'),
  lines: require('./lines'),
  settings: require('./settings'),
  scores: require('./scores'),
  signup: require('./signup'),
  simulator: require('./simulator'),
  users: require('./users') 
};
