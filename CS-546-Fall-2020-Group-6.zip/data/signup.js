const c = require('../config');
const {db} = require('../config');

/*
userdata = new sign( {
	
    unique_id: Number,
    firstname: String,
    lastname: String,
	email: String,
	password: String,
	passwordConf: String
}),
User = mongoCollections.data('User', userdata);

module.exports = User;
*/